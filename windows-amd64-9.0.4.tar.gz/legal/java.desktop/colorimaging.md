## Eastman Kodak Company: Kodak Color Management System (kcms) and portions of color management and imaging software

### Eastman Kodak Notice
<pre>
Portions Copyright Eastman Kodak Company 1991-2003
</pre>

