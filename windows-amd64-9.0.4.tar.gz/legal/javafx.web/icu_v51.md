Please see ..\javafx.graphics\icu_v51.md
